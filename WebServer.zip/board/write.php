<!DOCTYPE>
 
<html>
<head>
        <meta charset = 'utf-8'>
	<link rel="stylesheet" href="../css/common.css">
</head>
<style>
        table.table2{
                border-collapse: separate;
                border-spacing: 1px;
		margin: 0 auto;
                text-align: left;
                line-height: 1.5;
                border-top: 1px solid #ccc;
        }
        table.table2 tr {
                width: 50px;
                padding: 10px;
                font-weight: bold;
                vertical-align: top;
                border-bottom: 1px solid #ccc;
        }
        table.table2 td {
                 width: 100px;
                 padding: 10px;
                 vertical-align: top;
                 border-bottom: 1px solid #ccc;
        }

	.view_title {
		height: 30px;
		text-align: center;
		margin-top: 30px;
		margin: auto;
                font-weight: bold;
		width: 8888888800px;
	}

 
</style>
<body>
    <header>
    <!-- 공통모듈 lib -->
    <?php include "../lib/header2.php"; ?>
    </header>

        <?php
                session_start();
                $URL = "./board_list.php";
                if(!isset($_SESSION['userid'])) {
        ?>
 
                <script>
                        alert("로그인이 필요합니다");
                        location.replace("<?php echo $URL?>");
                </script>
        <?php
                }
        ?>

        <form method = "get" action = "write_action.php">
        <table  style="padding-top:50px" align = center width=1220 border=0 cellpadding=2 >
                <tr>
                	<td colspan="5" class="view_title" >글쓰기</td>
                </tr>
                <tr>
                <td bgcolor=white>
                <table class = "table2">
                        <tr>
                        <td>작성자</td>
                        <td><input type = text name = name size=20> </td>
                        </tr>
 
                        <tr>
                        <td>제목</td>
                        <td><input type = text name = title size=60></td>
                        </tr>
 
                        <tr>
                        <td>내용</td>
                        <td><textarea name = content cols=85 rows=15></textarea></td>
                        </tr>
 
                        <tr>
                        <td>비밀번호</td>
                        <td><input type = password name = pw size=10 maxlength=10></td>
                        </tr>
                        </table>
 
                        <center>
                        <input type = "submit" value="작성">
                        </center>
                </td>
                </tr>
        </table>
        </form>
    <footer>
    <!-- 공통모듈 lib -->
    <?php include "../lib/footer.php"; ?>
</body>
</html>




