<!DOCTYPE html>
 
<html>
<head>
        <meta charset = 'UTF-8'>
	<title> 게시판 </title>

	<link rel="stylesheet" href="../css/common.css">
	<link rel="stylesheet" href="../css/board.css">
</head>
<style>
        table{
                border-top: 1px solid #444444;
                border-collapse: collapse;
		margin-top: 30px;
		width: 1000px; margin: 0 auto;
        }
        tr{
                border-bottom: 1px solid #444444;
                padding: 10px;
        }
        td{
                border-bottom: 1px solid #efefef;
                padding: 10px;
        }
        table .even{
                background: #efefef;
        }
	
	.write_btn {
	width: 700px;
	height: 200px;
	text-align: center;
	margin: auto;
	margin-top: 50px;
	}

        .write_btn1 {
	height: 50px;
	width: 100px;
	font-size: 20px;
	text-align: center;
	background-color: white;
	border: 2px solid black;
	border-radius: 10px;
	}

        .text:hover{
                text-decoration: underline;
        }
        a:link {color : #57A0EE; text-decoration:none;}
        a:hover { text-decoration : underline;}
</style>

<body>
 	<header>
   		<?php include "../lib/header2.php";?>
 	</header>
<?php
                $connect = mysqli_connect('localhost', 'dong', 'dong', 'dbdong') or die ("connect fail");
                $query ="select * from board order by number desc";
                $result = $connect->query($query);
                $total = mysqli_num_rows($result);
 
        ?>
	<div id="message_box">
        <h2> 게시판</h2>
	<div>
        <table align = center>
        <thead align = "center">
        <tr>
        <td width = "200" align="center">번호</td>
        <td width = "500" align = "center">제목</td>
        <td width = "200" align = "center">작성자</td>
        <td width = "200" align = "center">날짜</td>
        <td width = "200" align = "center">조회수</td>
        </tr>
        </thead>
 
        <tbody>
        <?php
                while($rows = mysqli_fetch_assoc($result)){ //DB에 저장된 데이터 수 (열 기준)
                        if($total%2==0){
        ?>                      <tr class = "even">
                        <?php   }
                        else{
        ?>                      <tr>
                        <?php } ?>
                <td width = "300" align = "center"><?php echo $total?></td>
                <td width = "500" align = "center">
                <a href = "view.php?number=<?php echo $rows['number']?>">
                <?php echo $rows['title']?></td>
                  <td width = "100" align = "center"><?php echo $rows['id']?></td>
                <td width = "200" align = "center"><?php echo $rows['date']?></td>
                <td width = "200" align = "center"><?php echo $rows['hit']?></td>
                </tr>
        <?php
                $total--;
                }
        ?>
        </tbody>
        </table>
 
        <div class = "write_btn">
        <button class="wrtie_btn1" onclick="location.href='./write.php'">글쓰기</button>
        </div> 
 
 
 	<footer>
  		<?php include "../lib/footer.php";?>
 	</footer> 
</body>
</html>


