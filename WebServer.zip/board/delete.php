<?php
    $connect = mysqli_connect("localhost", "dong", "dong", "dbdong") or die ("connect fail");
    $number = $_GET[number];
    $title = $_GET[title];
    $content = $_GET[content];
    $date = date('Y-m-d H:i:s');
    $query = "delete from board where number='$number'";
    $result = $connect->query($query);
    if($result) {
?>
        <script>
            alert("삭제되었습니다.");
            location.replace("./board_list.php");
        </script>
<?php    }
    else {
        echo "fail";
    }
?>


