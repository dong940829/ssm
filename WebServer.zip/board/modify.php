<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>수정</title>
 
        <link rel="stylesheet" href="../css/common.css">
   </head>
	<style>
	.modify_table {
	border: 1px solid #444444;
	width: 800px;
	margin: auto;
	margin-top: 50px;
	margin-bottom: 100px;
	}

	.view_title {
	height: 30px;
	text-align: center;
	margin-top: 30px;
	background-color: #cccccc;
	color: white;
	width: 8888888800px;
	}


	.view_id {
	text-align: center;
	background-color: #EEEEEE;
	width: 50px;
	}
	.view_id2 {
	background-color: white;
	width: 60px;
	}

	</style>

    <body>
        <header>
            <?php include "../lib/header2.php"; ?>
        </header>

      <?php    $connect = mysqli_connect("localhost","dong" ,"dong" , "dbdong" ) or die("connect fail");
                $id = $_GET[id];
                $number = $_GET[number];
                $query = "select title, content, date, id from board where number=$number";
                $result = $connect->query($query);
                $rows = mysqli_fetch_assoc($result);
 
                $title = $rows['title'];
                $content = $rows['content'];
                $usrid = $rows['id'];
 
                session_start();
 
 
                $URL = "./board_list.php";
 
                if(!isset($_SESSION['userid'])) {
        ?>              <script>
                                alert("권한이 없습니다.");
                                location.replace("<?php echo $URL?>");
                        </script>
        <?php   }
                else if($_SESSION['userid']==$usrid) {
        ?>
        <form method = "get" action = "modify_action.php">
        <table class="modify_table" align=center>
                <tr>
			 <td colspan="4" class="view_title"><?php echo $rows['title']?></td>
                </tr>
                <tr>
                <td bgcolor=white>
		<table class = "table2">
                <tr>
                        <td class="view_id">작성자</td>
               		<td class="view_id2"><?php echo $rows['id']?></td>

               </tr>
 
               <tr>
                        <td class="view_id">제목</td>
                        <td><input type = text name = title size=60 value="<?=$title?>"></td>
              </tr>
 
              <tr>
                        <td class="view_id">내용</td>
                        <td><textarea name = content cols=85 rows=15><?=$content?></textarea></td>
              </tr>
 
                        </table>
 
                        <center>
                        <input type="hidden" name="number" value="<?=$number?>">
                        <input type = "submit" value="작성">
                        </center>
                </td>
                </tr>
        </table>
        <?php   }
                else {
        ?>              <script>
                                alert("권한이 없습니다.");
                                location.replace("<?php echo $URL?>");
                        </script>
        <?php   }
        ?>




        <footer>
           <?php include "../lib/footer.php"; ?>
        </footer>
    </body>
</html>

