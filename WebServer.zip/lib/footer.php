<div id="footer_content">
    <p id="footer_logo">오징어 게임 | <span>깐부</span></p>
    <ul id="download">
       <!-- <li>예제 소스 다운로드</li>
        <li>- 한빛 아카데미<a href="http://hanbit.co.kr">(http://hanbit.co.kr)</a></li>
        <li>- 미래능력개발교육원<a href="http://www.mrhi.or.kr">(http://www.mrhi.or.kr)</a></li>-->
    </ul>
    <ul id="author">
        <li>저자 문의 메일</li>
        <li>- 메일 주소 : dong940829@nate.com</li>
    </ul>
</div>
