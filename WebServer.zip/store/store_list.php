<!DOCTYPE html>

<html>
<head>
        <meta charset = 'UTF-8'>
        <title> 온라인 스토어  </title>

        <link rel="stylesheet" href="../css/common.css">
        <link rel="stylesheet" href="../css/store.css">
</head>

<body>
        <header>
                <?php include "../lib/header2.php";?>
        </header>


   	 <div id="main_content">
        	<img src="../img/Bestseller.png">
        	<img src="../img/Bestsellerss.png">
        	<img src="../img/Categories.png">

        </article>
    </div>



        <footer>
                <?php include "../lib/footer.php";?>
        </footer>
</body>
</html>

